<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-4">
        <h4>Dashboard</h4>
        
        <div class="row mb-4">
            <div class="col-md-2">
                <div class="card bg-light text-dark mb-3">
                    <div class="card-header">Total Emails Sent</div>
                    <div class="card-body">
                        <p class="card-text"><?php echo e($totalEmailsSent); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="card bg-light text-dark mb-3">
                    <div class="card-header">Total Today</div>
                    <div class="card-body">
                        <p class="card-text"><?php echo e($totalEmailsSentToday); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="card bg-light text-dark mb-3">
                    <div class="card-header">Total This Week</div>
                    <div class="card-body">
                        <p class="card-text"><?php echo e($totalEmailsSentThisWeek); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="card bg-light text-dark mb-3">
                    <div class="card-header">Total This Month</div>
                    <div class="card-body">
                        <p class="card-text"><?php echo e($totalEmailsSentThisMonth); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="card bg-light text-dark mb-3">
                    <div class="card-header">Total This Year</div>
                    <div class="card-body">
                        <p class="card-text"><?php echo e($totalEmailsSentThisYear); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <h5 class="mt-4">Latest 5 Campaigns</h5>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Subject</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $latestCampaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($campaign->name); ?></td>
                        <td><?php echo e($campaign->subject); ?></td>
                        <td>
                            <form action="<?php echo e(route('start_campaign', $campaign->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary">Start</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shariqqcom/Projects/bms19/resources/views/dashboard.blade.php ENDPATH**/ ?>