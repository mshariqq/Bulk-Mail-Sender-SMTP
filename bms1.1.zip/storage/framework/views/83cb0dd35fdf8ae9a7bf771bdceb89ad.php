<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h4>Campaigns</h4>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-8">
                <a href="<?php echo e(route('email_campaign.create')); ?>" class="btn btn-primary mb-3">Create New Campaign</a>

                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>List</th>
                            <th>Status</th>
                            <th>Name</th>
                            <th>Subject</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($campaign->list_name); ?></td>
                                <td><?php echo e($campaign->emails_status); ?></td>
                                <td><?php echo e($campaign->name); ?></td>
                                <td><?php echo e($campaign->subject); ?></td>
                                <td><?php echo e($campaign->created_at->format('M d Y, h:i:s A')); ?></td>
                                <td>
                                    <button class="btn btn-success start-campaign" 
                                            data-id="<?php echo e($campaign->id); ?>" 
                                            data-emails-per-hour="<?php echo e($campaign->emails_per_hour); ?>">
                                        Start
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve(['paginator' => $campaigns] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
                    </tfoot>
                </table>
            </div>

            <div class="col-md-4">
                <div id="email-status" class="col-12 bg-light p-3 border border-info">
                    <p>Time remaining for next email: <span id="timer">--</span></p>
                    <p>Emails sent: <span id="emails-sent">0</span></p>
                </div>
                <div id="log" class="col-12 bg-dark text-warning p-3">
                    <p>LOG :</p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('.start-campaign').click(function() {
            const campaignId = $(this).data('id');
            const emailsPerHour = parseInt($(this).data('emails-per-hour'));

            // Calculate the delay between emails
            const delay = Math.floor((60 * 60 * 1000) / emailsPerHour); // Time in milliseconds
            const minDelay = delay - 500; // Adding some randomness
            const maxDelay = delay + 500; // Adding some randomness

            let emailsSent = 0;
            let timerInterval;

            function startTimer(duration) {
                let remainingTime = duration;

                if (timerInterval) {
                    clearInterval(timerInterval);
                }

                timerInterval = setInterval(function() {
                    if (remainingTime <= 0) {
                        clearInterval(timerInterval);
                        $('#timer').text('0 seconds');
                    } else {
                        $('#timer').text(Math.ceil(remainingTime / 1000) + ' seconds');
                        remainingTime -= 1000; // Decrease by 1 second
                    }
                }, 1000);
            }

            function sendNextEmail() {
                $.ajax({
                    url: '<?php echo e(route('email_campaign.start')); ?>',
                    method: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        campaign_id: campaignId
                    },
                    success: function(response) {
                        if (response.error) {
                            $('#log').append(response.error + '<br>');
                            alert(response.error);
                        } else {
                            emailsSent++;
                            $('#log').append(response.success + '<br>');
                            $('#emails-sent').text(emailsSent);

                            // Random delay between minDelay and maxDelay
                            const randomDelay = Math.floor(Math.random() * (maxDelay - minDelay + 1)) + minDelay;
                            
                            // Start the countdown timer for the next email
                            startTimer(randomDelay);
                            
                            setTimeout(sendNextEmail, randomDelay);
                        }
                    },
                    error: function() {
                        alert('An error occurred while sending emails.');
                    }
                });
            }

            // Start the email sending process
            sendNextEmail();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shariqqcom/Projects/bms19/resources/views/email_campaign/index.blade.php ENDPATH**/ ?>