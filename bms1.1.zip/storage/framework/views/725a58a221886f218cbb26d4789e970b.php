<?php $__env->startSection('css'); ?>
   <style>
     tbody {
        color: #54595f;
    }
   </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-4">

<div class="row">
    <div class="col-md-6">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <b>Email List Import</b>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('email_list.import')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group">
                        <label for="csv_file">Upload CSV File</label>
                        <input type="file" name="csv_file" id="csv_file" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Import</button>
                </form>
            </div>
        </div>

    </div>

    <div class="col-md-6">

        <ul>
            <li>The CSV file should be in UTF-8 encoding.</li>
            <li>Each row should contain the following columns in this order:
                <ul>
                    <li><strong>Email:</strong> The email address.</li>
                    <li><strong>Company Name:</strong> (Optional) The company name.</li>
                    <li><strong>Person Name:</strong> (Optional) The person's name.</li>
                    <li><strong>Country:</strong> (Optional) The country.</li>
                    <li><strong>City:</strong> (Optional) The city.</li>
                </ul>
            </li>
            <li>Ensure that there are no empty headers or extraneous columns.</li>
            <li>Use commas to separate values and avoid including quotes.</li>
           
        </ul>


    </div>

    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <b>Emails in the Database</b>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('email_list.delete_multiple')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
        
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>
                                        <input type="checkbox" id="select-all" />
                                    </th>
                                    <th>Email</th>
                                    <th>Company Name</th>
                                    <th>Person Name</th>
                                    <th>Country</th>
                                    <th>City</th>
                                    <th>List Name</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $emailLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emailList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="ids[]" value="<?php echo e($emailList->id); ?>" />
                                        </td>
                                        <td><?php echo e($emailList->email); ?></td>
                                        <td><?php echo e($emailList->company_name); ?></td>
                                        <td><?php echo e($emailList->person_name); ?></td>
                                        <td><?php echo e($emailList->country); ?></td>
                                        <td><?php echo e($emailList->city); ?></td>
                                        <td><?php echo e($emailList->list_name); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('email_list.destroy', $emailList->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No records found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
        
                    <button type="submit" class="btn btn-danger">Delete Selected</button>
                </form>
            </div>
            <div class="card-footer bg-light">
                <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve(['paginator' => $emailLists] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>

            </div>
        </div>

    </div>
</div>
        



    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#select-all').click(function() {
            $('input[name="ids[]"]').prop('checked', this.checked);
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shariqqcom/Projects/bms19/resources/views/email_list/index.blade.php ENDPATH**/ ?>